<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CampaignCard extends Model
{
    protected $table = 'campaign_cards';
}
